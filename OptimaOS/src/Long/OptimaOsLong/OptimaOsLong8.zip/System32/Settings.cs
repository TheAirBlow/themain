﻿using System;
using System.Collections.Generic;
using System.Text;

namespace OptimaOs.System32
{
    class Settings
    {
        public static string name_os = "OptimaOs";
        public static string version_os = "v0.0.8";
        public static int build_os = 8;
        public static string name_user = "Guest";
        public static bool sudos = false; 
    }
}
